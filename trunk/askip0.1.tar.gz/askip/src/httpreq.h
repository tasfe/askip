/*
 * httpreq.h
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef HTTPREQ_H_
#define HTTPREQ_H_

#include "askip.h"

typedef struct HttpReq
{
	char buf[4096];
	int w, size;
}HttpReq;

int  httpreq_init(HttpReq *req);
int  httpreq_setcont(HttpReq *req, char *host, char *file);
void httpreq_free(HttpReq *req);



#endif /* HTTPREQ_H_ */
