/*
 * url.c
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "url.h"
#include "urlfile.h"

/********************************************************************
 *  URL  去重
 */
#define HASH_LEN 1000000
#define HASH_KEY_LEN HASH_LEN * 8
char hashTable[HASH_LEN] = {0};

int getHashKey(char *p)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(p != NULL);
	int hash = 0;
	while(*p != '\0') {
		hash = (hash << 7) + *p;
		p++;
	}
	if(hash < 0) hash = -hash;
	return hash % HASH_KEY_LEN;
}

int inUrlHash(char *urlStr)
{
	YG_DEBUG("entry!\n");

    int hKey = getHashKey(urlStr);
    int idx = hKey / 8, pos = hKey % 8;
    if((hashTable[idx] & (1 << pos)) == 1) return 1;
    hashTable[idx] |= (1 << pos);
    return 0;
}


/*****************************************************************
 *  url  operator
 *
 */
int url_init(Url *url)
{
	YG_ASSERT(url != NULL);

	memset(url, 0, sizeof(Url));
	url->state = URL_INIT;

	return 0;
}

int url_set_netaddr(Url *url, char *ip)
{
	YG_ASSERT(url != NULL);
	if(ip == NULL || ip[0] == '\0') return -1;

	url->serv_addr.sin_family = AF_INET;
	url->serv_addr.sin_port = htons(80);
	if(inet_pton(AF_INET, ip, &((url->serv_addr).sin_addr)) != 1)  return -1;
	return 0;
}


const char url_safe_char[256] = {
	    ['/'] = 1, ['.'] = 1, ['?'] = 1, ['='] = 1, ['&'] = 1, ['#'] = 1,
	    ['~'] = 1, ['@'] = 1, ['#'] = 1, ['$'] = 1, ['%'] = 1, ['^'] = 1,
	    ['*'] = 1, ['('] = 1, [')'] = 1, ['+'] = 1, ['='] = 1, ['-'] = 1,
	    ['{'] = 1, ['}'] = 1, ['['] = 1, [']'] = 1, [':'] = 1, [';'] = 1,
	    ['\''] = 1,['\"'] = 1,['<'] = 1, ['>'] = 1, [','] = 1, ['`'] = 1,
	    ['|'] = 1, ['\\'] = 1,['_'] = 1,
};

int is_num_char(char c)
{
	if(c >= '0' && c <= '9') return 1;
	if(c >= 'A' && c <= 'a') return 1;
	if(c >= 'a' && c <= 'z') return 1;

	return 0;
}


int is_valid_url(char *urlStr)
{
	char *p = urlStr;
	if(p == NULL) return 0;
	while(*p != '\0') {
		if(is_num_char(*p) == 0 && url_safe_char[(unsigned char)(*p)] == 0) return 0;
		p++;
	}

	//printf("====    %s\n", urlStr);

	return 1;
}

char hostBlack[10][64] = {
	"baidu.com"
};
int hostBlackLen = 1;

char hostWhite[10][64] = {
	"www.baidu.com",
	"cache.baidu.com"
};
int hostWhiteLen = 2;

int inhostblack(char *host)
{
	int i;
	for(i = 0; i < hostBlackLen; i++)
		if(yg_str_ewith(host, hostBlack[i]) == 0) return 1;
	return 0;
}

int inhostwhite(char *host)
{
	int i;
	for(i = 0; i < hostWhiteLen; i++)
		if(yg_str_ewith(host, hostWhite[i]) == 0) return 1;
	return 0;
}

int url_check_host(char *host) {
	if(host == NULL || *host == '\0') return -1;

	if(inhostblack(host)) {
		if(inhostwhite(host)) return 0;
		return -1;
	}
	return 0;
}

int url_check(Url *url)
{
	YG_DEBUG("entry!\n");

	if(url == NULL) return -1;
	if(url_check_host(url->host) == -1) return -1;
	if(strlen(url->file) == 0) return -1;

	return 0;
}

int url_parse(char *urlStr, Url *parentUrl)
{
	YG_DEBUG("entry!\n");

	if(urlStr == NULL) return -1;
	if(is_valid_url(urlStr) != 1) return 0;
    if(inUrlHash(urlStr) > 0)  return 0;

    char *host = NULL;
    char *file = NULL;
	Url newUrl;
	url_init(&newUrl);
    if(strncasecmp(urlStr, "http", strlen("http")) == 0) {
    	host = yg_get_domain(urlStr);
    	if(host == NULL)  goto ERR;
        file = yg_get_file(urlStr);
        if(file == NULL)  goto ERR;

        newUrl.depth = global.depth;
        if(parentUrl != NULL)
        	newUrl.depth = parentUrl->depth - 1;
    }
    else{
        if(parentUrl == NULL) return -1;

        YG_STRDUP(host, parentUrl->host);

        if(urlStr[0] == '/')
        	file = yg_get_file1(urlStr);
        else
        	file = yg_get_file2(urlStr, parentUrl->file);
        if(file == NULL) goto ERR;

        newUrl.depth = parentUrl->depth - 1;
    }

    strncpy(newUrl.host, host, sizeof(newUrl.host) - 1);
    strncpy(newUrl.file, file, sizeof(newUrl.file) - 1);
	YG_FREE(host);
	YG_FREE(file);

    if(url_check(&newUrl) == -1) return -1;
    urlfile_write(&newUrl);
    return 0;

ERR:
	YG_FREE(host);
	YG_FREE(file);
    return -1;
}

int url_destory(Url *url)
{
	YG_INFO("entry!\n");

	if(url == NULL) return 0;
	if(url->state == URL_INIT) return 0;

	sk_adns_destory(&(url->skAdns));
	url->state = URL_INIT;
	global.urlCount -= 1;

	return 0;
}
