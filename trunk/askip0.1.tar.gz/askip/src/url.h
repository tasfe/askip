/*
 * skurl.h
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef SKURL_H_
#define SKURL_H_

#include "askip.h"
#include "yg_net.h"
#include "dns_server.h"
#include "sk_adns.h"

enum UrlState {
    URL_INIT = 0,
    URL_DNS = 1,
    URL_CONN = 2,
    URL_RUN = 3
};

typedef struct Url
{
	char state;
    char host[255];
    char file[255];
	int port;
    int depth;
    char isAdns;
    struct SkAdns skAdns;
    struct sockaddr_in serv_addr;
}Url;

int url_init(Url *url);
int url_set_netaddr(Url *url, char *ip);
int url_check(Url *url);
int url_parse(char *urlStr, Url *parentUrl);
int url_destory(Url *url);

#endif /* SKURL_H_ */
