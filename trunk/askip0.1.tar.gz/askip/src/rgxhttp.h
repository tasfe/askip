/*
 * rgxhttp.h
 *
 *   Created on: 2011-12-9
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef RGXHTTP_H_
#define RGXHTTP_H_

#include "url.h"

int rgxhttp_init();
int rgxhttp_match(char *str, Url *oldUrl);
void rgxhttp_free();

#endif /* RGXHTTP_H_ */
