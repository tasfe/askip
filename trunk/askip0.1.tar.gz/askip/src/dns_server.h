/*
 * dnsmap.h
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef DNSMAP_H_
#define DNSMAP_H_

#include "askip.h"

int dns_server_init();
char* dns_server_getip(char *host);
void dns_server_put(char *host, char *ip);
void dns_server_destory();

#endif /* DNSMAP_H_ */
