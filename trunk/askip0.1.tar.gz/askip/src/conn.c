/*
 * conn.c
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */
#include "conn.h"

int conn_init(Conn *conn)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(conn != NULL);
	//conn_destory(conn);

	conn->state = CONN_INIT;
	conn->fd = -1;
	conn->tryCount = TRY_COUNT;
	conn->url = NULL;

	YG_ASSERT(httpreq_init(&(conn->req)) == 0);
	YG_ASSERT(rsp_init(&(conn->rsp)) == 0);

	return 0;
}

void conn_destory(Conn *conn)
{
	YG_INFO("entry!");

	YG_ASSERT(conn != NULL);

	url_destory(conn->url);
	conn->url = NULL;

	conn->state = CONN_INIT;
	if(conn->fd != -1) {
		close(conn->fd);
		conn->fd = -1;
	}
	global.connCount -= 1;
	//if(conn->url != NULL) {
	//}
	//conn->tryCount = TRY_COUNT;
	rsp_free(&(conn->rsp));
	httpreq_free(&(conn->req));
}

int conn_bind(Conn *conn)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(conn != NULL);

	Url *url = conn->url;
	int sock_fd;
	int iflag;

	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) return -1;

    int flag = fcntl(sock_fd, F_GETFL, 0);
    if(flag < 0) return -1;
    if(fcntl(sock_fd, F_SETFL, flag | O_NONBLOCK) < 0) return -1;

    conn->fd = sock_fd;
    iflag = connect(sock_fd, (struct sockaddr *)(&(url->serv_addr)), sizeof(url->serv_addr));
	if(iflag == 0 || errno == EINPROGRESS) {
		conn->state = CONN_WRITE;
		httpreq_setcont(&(conn->req), url->host, url->file);
	} else {
		printf("error: %d = %s\n", errno, strerror(errno));
		return -1;
	}

	return 0;
}

int write_content(Conn *conn)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(conn != NULL);

	HttpReq *req = &(conn->req);

	int sendLen = write(conn->fd, req->buf + req->w, req->size - req->w);
	if(sendLen == -1) {
		printf("error: %d = %s\n", errno, strerror(errno));
		conn_destory(conn);
		return -1;
	}

	req->w += sendLen;
	if(req->w == req->size)
		conn->state = CONN_READ;

    return 0;
}

void writeToHtml(char *host, char *file, char *buff)
{
	int i;
    char fname[512];

    memset(fname, 0, sizeof(fname));
    sprintf(fname, "html/%s/%s", host, file);
    int flen = strlen(fname);
    for(i = 5; i < flen; i++)
        if(fname[i] == '/')
            fname[i]= '_';
    FILE *fw = fopen(fname, "a");
    if(fw == NULL) return;
    fprintf(fw, "%s", buff);
    fclose(fw);
}

int read_content(Conn *conn)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(conn != NULL);

	int tempw;
	Rsp *rsp = &(conn->rsp);

	//YG_WARN("r: %d, w: %d", rsp->r, rsp->w);

	if(rsp->r > 0) {
		yg_str_move(rsp->buf, rsp->r, rsp->w - rsp->r);
		rsp->w -= rsp->r;
		rsp->r = 0;
	}

    int flag = read(conn->fd, rsp->buf + rsp->w, rsp->limit - rsp->w - 1);

    //YG_WARN("w: %d, limit : %d, flag : %d", rsp->w, rsp->limit, flag);
    if(rsp->w < 0) exit(0);

    switch(flag) {
        case -1:
            conn_destory(conn);
            return -1;
        case 0:
        	html_parse(rsp, conn->url);
            conn_destory(conn);
            break;
        default:
            rsp->w += flag;
            rsp->buf[rsp->w] = '\0';
            html_parse(rsp, conn->url);

            if(rsp->state == RES_ST_END)
            	conn_destory(conn);
            break;
    }

    return flag;
}

