/*
 * htmlparse.h
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef HTMLPARSE_H_
#define HTMLPARSE_H_

#include "rgxhttp.h"
#include "yg_table.h"

#define RSP_BUF_SIZE (4096 * 4)

#define RES_ST_STATE 1
#define RES_ST_HEAD	2
#define RES_ST_BODY	3
#define RES_ST_END  4

typedef struct Rsp
{
	int state;

	char *proto;
	int stateCode;
	char *reason;
	struct YgTable *resHead;
	int isChunk;
	int contlen;

	int r, w;
	int limit;
	char buf[RSP_BUF_SIZE];
}Rsp;

int rsp_init(Rsp *rsp);
void rsp_free(Rsp *rsp);
int html_parse(Rsp *rsp, Url *oldUrl);



#endif /* HTMLPARSE_H_ */
