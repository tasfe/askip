/*
 * skcfg.c
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "urlpool.h"

#define SK_CFG_PATH  "./cfg.txt"


int readcfg()
{
	FILE *cfp = fopen(SK_CFG_PATH, "r");
	YG_ASSERT(cfp != NULL);

	char line[4096];
	while(true) {
		if(fgets(line, sizeof(line) - 1, cfp) == NULL)
			break;
		line[strlen(line) - 1] = '\0';
		url_parse(line, NULL);
	}

	fclose(cfp);
	return 0;
}

