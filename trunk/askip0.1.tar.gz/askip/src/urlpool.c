/*
 * urlpool.c
 *
 *   Created on: 2011-12-3
 *       Author:
 *  Description: 
 */

#include "urlpool.h"


#define URLPOOL_SIZE 128
static Url urlPool[URLPOOL_SIZE];

int urlpool_init()
{
	int i;
	for(i = 0; i < URLPOOL_SIZE; i++)
		urlPool[i].state = URL_INIT;
		//YG_ASSERT(url_init(&(urlPool[i])) == 0);

	return 0;
}

int urlpool_isempty()
{
	int i;
	for(i = 0; i < URLPOOL_SIZE; i++)
		if(urlPool[i].state != URL_INIT) return 0;

	return 1;
}

int urlpool_full()
{
	YG_DEBUG("entry!\n");

	int iflag;
	int i;
	for(i = 0; i < URLPOOL_SIZE; i++) {
		if(urlPool[i].state == URL_INIT) {
			YG_ASSERT(url_init(&(urlPool[i])) == 0);
			while(1) {
				iflag = urlfile_read(&(urlPool[i]));
				if(iflag == -2) return 0;
				else if(iflag == 0) break;
			}
			urlPool[i].state = URL_DNS;
		}
	}

	return 0;
}


int urlpool_dns_full()
{
	char *ip;
	int i;
	Url *pUrl;

	//YG_INFO("entry");

	for(i = 0; i < URLPOOL_SIZE; i++) {
		pUrl = &(urlPool[i]);

		if(pUrl->state == URL_DNS) {
			// 先判断是不是IP：PORT
			if(pUrl->isAdns == 0) {
				ip = dns_server_getip(pUrl->host);
				if(ip != NULL) {
					if(url_set_netaddr(pUrl, ip) == -1) url_destory(pUrl);
					else pUrl->state = URL_CONN;
				} else {
					pUrl->isAdns = 1;
					YG_ASSERT(sk_adns_init(&(pUrl->skAdns)) == 0);
					YG_ASSERT(sk_adns_commit(&(pUrl->skAdns), pUrl->host) == 0);
				}
			} else {
				ip = sk_adns_query(&(pUrl->skAdns));
				if(ip != NULL) {
					if(url_set_netaddr(pUrl, ip) == -1) url_destory(pUrl);
					else {
						pUrl->state = URL_CONN;
						dns_server_put(pUrl->host, ip);
					}
				} else if(pUrl->skAdns.tryCount == MAX_DNS_COUNT) {
					url_destory(pUrl);
				}
			}
		}
	}

	return 0;
}

Url* urlpool_get_url()
{
	YG_DEBUG("entry!\n");

	int i;
	for(i = 0; i < URLPOOL_SIZE; i++) {
		if(urlPool[i].state == URL_CONN) {
			global.urlCount += 1;
			urlPool[i].state = URL_RUN;
			return &(urlPool[i]);
		}
	}

	return NULL;
}

void urlpool_destory()
{
	int i;
	for(i = 0; i < URLPOOL_SIZE; i++)
		url_destory(&(urlPool[i]));
}

void urlpool_output()
{
	int init = 0, dns = 0, use = 0, run = 0;
	int i;
	for(i = 0; i < URLPOOL_SIZE; i++) {
		if(urlPool[i].state == URL_INIT) {
			init++;
		} else if(urlPool[i].state == URL_DNS) {
			dns++;
		}else if(urlPool[i].state == URL_CONN) {
			use++;
		}
		else if(urlPool[i].state == URL_RUN) {
			run++;
		}
	}

	printf("urlpool total: init = %d, dns = %d,  use = %d, run = %d\n", init, dns, use, run);
}

