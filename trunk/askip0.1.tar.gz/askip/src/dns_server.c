/*
 * HostMap.c
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "dns_server.h"

typedef struct DnsNode {
	unsigned int hostLen;
	char host[255];
	char ip[32];
} DnsNode;

#define HOST_MAP_LEN 4096
DnsNode dnsPool[HOST_MAP_LEN];

void dns_node_init(DnsNode *node)
{
	YG_ASSERT(node != NULL);

	memset(node, 0, sizeof(node));
}

int dns_node_cmp(DnsNode *node, char *host)
{
	int hostLen = strlen(host);
	if (node->hostLen != hostLen || strncmp(node->host, host, node->hostLen) != 0)
		return -1;
	return 0;
}

void dns_node_free(DnsNode *node)
{
	YG_ASSERT(node != NULL);
}

void dns_node_set(DnsNode *node, char *host, char *ip)
{
	YG_ASSERT(node != NULL);
	YG_ASSERT(host != NULL);
	YG_ASSERT(ip != NULL);

	dns_node_free(node);
	node->hostLen = strlen(host);

	strncpy(node->host, host, sizeof(node->host));
	strncpy(node->ip, ip, sizeof(node->ip));
}



int dns_server_init()
{
	int i;
	for (i = 0; i < HOST_MAP_LEN; i++) {
		dns_node_init(&(dnsPool[i]));
	}

	return 0;
}

void dns_server_put(char *host, char *ip)
{
	YG_DEBUG("entry!\n");
	YG_ASSERT(host != NULL);
	YG_ASSERT(ip != NULL);

	int hashKey = yg_gethash(host, HOST_MAP_LEN);
	YG_ASSERT(hashKey != -1);

	DnsNode dnsNode = dnsPool[hashKey];
	dns_node_set(&dnsNode, host, ip);
}

char* dns_server_getip(char *host)
{
	YG_DEBUG("entry!\n");
	YG_ASSERT(host != NULL);

	int hashKey = yg_gethash(host, HOST_MAP_LEN);
	YG_ASSERT(hashKey != -1);

	DnsNode dnsNode = dnsPool[hashKey];
	if (dns_node_cmp(&dnsNode, host) != 0)
		return NULL;

	return dnsNode.ip;
}

void dns_server_destory()
{
	int i;
	for (i = 0; i < HOST_MAP_LEN; i++)
		dns_node_free(&(dnsPool[i]));
}
