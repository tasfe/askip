/*
 * connpool.h
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef CONNPOOL_H_
#define CONNPOOL_H_

#include "urlpool.h"
#include "conn.h"


int  connpool_init();
int  connpool_isempty();
int  connpool_full();
int  do_fetch();
void connpool_destory();
void connpool_output();

#endif /* CONNPOOL_H_ */
