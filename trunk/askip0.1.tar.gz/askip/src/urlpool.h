/*
 * urlpool.h
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef URLPOOL_H_
#define URLPOOL_H_

#include "url.h"
#include "urlfile.h"


int  urlpool_init();
int  urlpool_isempty();
Url* urlpool_get_url();
int  urlpool_full();
int  urlpool_dns_full();
void urlpool_destory();

void urlpool_output();


#endif /* URLPOOL_H_ */
