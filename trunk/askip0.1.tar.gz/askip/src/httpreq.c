/*
 * httpreq.c
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "httpreq.h"

int httpreq_init(HttpReq *req)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(req != NULL);

	memset(req, 0, sizeof(HttpReq));
	req->size = sizeof(req->buf);

	return 0;
}

int httpreq_setcont(HttpReq *req, char *host, char *file)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(req != NULL);
	YG_ASSERT(host != NULL);
	YG_ASSERT(file != NULL);

	snprintf(req->buf, req->size,
			"GET %s HTTP/1.1\r\n"
			"Host: %s\r\n"
			"User-Agent: Mozilla/4.0 (compatible; MSIE 7.0; Widows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022)\r\n"
			"Accept: */*\r\n\r\n",
			file, host);
	req->size = strlen(req->buf);

	return 0;
}
void httpreq_free(HttpReq *req)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(req != NULL);

	memset(req, 0, sizeof(HttpReq));
	req->size = sizeof(req->buf);
}
