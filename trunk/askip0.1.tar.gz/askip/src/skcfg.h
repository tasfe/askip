/*
 * skcfg.h
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef SKCFG_H_
#define SKCFG_H_

int readcfg();

#endif /* SKCFG_H_ */
