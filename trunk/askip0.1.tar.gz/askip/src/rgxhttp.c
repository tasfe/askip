/*
 * rgxhttp.c
 *
 *   Created on: 2011-12-9
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "rgxhttp.h"


#define RGX_HTTP_SIZE 8
regex_t rgxHttp[RGX_HTTP_SIZE];

char rgxStr[RGX_HTTP_SIZE][128] = {
	"<a href=\"([^\"]+)\""
};
int rgxHttpSize = 1;


int rgxhttp_init()
{
	char errbuf[512];
	int i;
	for(i = 0; i < rgxHttpSize; i++) {
		int iflag = regcomp(&rgxHttp[i], rgxStr[i], REG_EXTENDED | REG_NEWLINE);
		if(iflag != 0) {
			regerror(iflag, &rgxHttp[i], errbuf, sizeof(errbuf));
			fprintf(stderr, "regcomp err: %s\n", errbuf);
			YG_ASSERT(iflag != 0);
		}
	}

	return 0;
}

int rgxhttp_match_str(char *str, regex_t *rgx, Url *oldUrl)
{
	YG_DEBUG("entry!\n");

	if(str == NULL || *str == '\0' || rgx == NULL)
		return -1;

	char *p = str;

	char *buf;
	int len, iflag;
	regmatch_t pmatch[2];

	while(1) {
		if(p == NULL || *p == '\0') break;
		iflag = regexec(rgx, p, 2, pmatch, 0);
		if(iflag != 0) {
			//char errbuf[512];
			//regerror(iflag, rgx, errbuf, sizeof(errbuf));
			//fprintf(stderr, "regexec err: %s\n", errbuf);
			return 0;
		}

		if(pmatch[0].rm_eo == 0) return -2;

		len = pmatch[1].rm_eo - pmatch[1].rm_so;
		YG_MALLOC(buf, len + 1, char *);
		strncpy(buf, p + pmatch[1].rm_so, len);
		//printf("URL: %s\n", buf);
		url_parse(buf, oldUrl);
		YG_FREE(buf);

		p = p + pmatch[0].rm_eo;
	}

	return -2;
}

int rgxhttp_match(char *str, Url *oldUrl)
{
	YG_DEBUG("entry!\n");

	if(str == NULL || strlen(str) == 0)
		return -1;

	int i;
	for(i = 0; i < rgxHttpSize; i++) {
		rgxhttp_match_str(str, &rgxHttp[i], oldUrl);
	}

	return 0;
}


void rgxhttp_free()
{
	int i;
	for(i = 0; i < rgxHttpSize; i++) {
		regfree(&rgxHttp[i]);
	}
}
