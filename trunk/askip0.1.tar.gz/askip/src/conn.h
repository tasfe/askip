/*
 * conn.h
 *
 *   Created on: 2011-12-10
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef CONN_H_
#define CONN_H_

#include "htmlparse.h"
#include "httpreq.h"

enum CONN_STATE {
    CONN_INIT = 0,
    CONN_USE = 1,
    CONN_WRITE = 2,
    CONN_READ = 3
};

#define TRY_COUNT 4

typedef struct Conn {
	int state;
	int fd;
	Url *url;
    int tryCount;
    Rsp rsp;
    HttpReq req;
}Conn;

int  conn_init(Conn *conn);
int  conn_bind(Conn *conn);
int  write_content(Conn *conn);
int  read_content(Conn *conn);
void conn_destory(Conn *conn);


#endif /* CONN_H_ */
