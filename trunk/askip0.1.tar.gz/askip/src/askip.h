/*
 * askip.h
 *
 *  Created on: 2012-2-14
 *      Author: test
 */

#ifndef ASKIP_H_
#define ASKIP_H_

#include "syshead.h"
#include "yg_daemon.h"
#include "yg_err.h"
#include "yg_mem.h"
#include "yg_log.h"
#include "yg_str.h"

typedef struct Global
{
	int depth;
	char *startUrl;
	unsigned int inDomain;        // 是否保证只在startUrl同域名内部

	char isRunning;

	int urlCount;
	int connCount;
}Global;


extern Global global;


#endif /* ASKIP_H_ */
