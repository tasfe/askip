/*
 * urlfile.h
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef URLFILE_H_
#define URLFILE_H_

#include "askip.h"
#include "url.h"

int  urlfile_init();
int  urlfile_read(Url *url);
int  urlfile_write(Url *url);
void urlfile_destory();



#endif /* URLFILE_H_ */
