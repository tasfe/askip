/*
 * connpool.c
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "connpool.h"

#define CONNPOOL_SIZE 128
Conn connPool[CONNPOOL_SIZE];

int connpool_init()
{
	int i;
    for(i = 0; i < CONNPOOL_SIZE; i++) {
    	//  多次分配将导致内存泄漏， 在conn_init 里面需，先判断是否内存已经被释放掉，否则会多次分配引起内存泄漏
    	//YG_ASSERT(conn_init(&(connPool[i])) == 0);
    	connPool[i].state = CONN_INIT;
    	connPool[i].fd = -1;
    	connPool[i].tryCount = TRY_COUNT;
    }

    return 0;
}

int connpool_isempty()
{
	int i;
    for(i = 0; i < CONNPOOL_SIZE; i++) {
    	if(connPool[i].state != CONN_INIT) return 0;
    }

    return 1;
}

int connpool_full()
{
	YG_DEBUG("entry!\n");

	int i;
    for(i = 0; i < CONNPOOL_SIZE; i++) {

    	if(connPool[i].state != CONN_INIT) {
        	connPool[i].tryCount -= 1;
        	if(connPool[i].tryCount <= 0) {
        	    conn_destory(&(connPool[i]));
        	}
    	}

        if(connPool[i].state == CONN_INIT) {
        	Url *url = NULL;

			url = urlpool_get_url();
			if(url == NULL) return 0;

        	conn_init(&connPool[i]);
        	global.connCount += 1;
        	connPool[i].url = url;
        	if(conn_bind(&(connPool[i])) == -1)
        		conn_destory(&(connPool[i]));
        }
    }

    return 0;
}


int do_fetch()
{
	YG_DEBUG("entry!\n");

    fd_set r_fds, w_fds;
    FD_ZERO(&w_fds);
    FD_ZERO(&r_fds);

    int maxfd = -1;
    int i;
    for(i = 0; i < CONNPOOL_SIZE; i++) {
        if(connPool[i].state == CONN_WRITE) {
            FD_SET(connPool[i].fd, &w_fds);
            if(connPool[i].fd > maxfd) maxfd = connPool[i].fd;
        }
        else if(connPool[i].state == CONN_READ) {
            FD_SET(connPool[i].fd, &r_fds);
            if(connPool[i].fd > maxfd) maxfd = connPool[i].fd;
        }
    }
    if(maxfd == -1) {
    	/*
    	global.isRunning = 0;
    	return -1;
    	*/
    	return 0;
    }

    struct timeval timeo;
    timeo.tv_sec = 3;
    timeo.tv_usec = 0;
    if(select(maxfd + 1, &r_fds, &w_fds, NULL, &timeo) <= 0) return 0;

    for(i = 0; i < CONNPOOL_SIZE; i++) {

        if(connPool[i].state == CONN_WRITE) {
            if(FD_ISSET(connPool[i].fd , &w_fds) != 0) {
            	connPool[i].tryCount = TRY_COUNT;
            	write_content(&(connPool[i]));
            }
        }
        if(connPool[i].state == CONN_READ)  {
            if(FD_ISSET(connPool[i].fd , &r_fds) != 0) {
                read_content(&connPool[i]);
                connPool[i].tryCount = TRY_COUNT;
            }
        }
    }

    return 0;
}

void connpool_destory()
{
	int i;
    for(i = 0; i < CONNPOOL_SIZE; i++)
    	conn_destory(&(connPool[i]));
}

void connpool_output()
{
	int init = 0, use = 0, build = 0, write = 0, read = 0;
	int i;
	for(i = 0; i < CONNPOOL_SIZE; i++) {
		if(connPool[i].state == CONN_INIT) {
			init++;
		} else if(connPool[i].state == CONN_USE) {
			use++;
		}
		else if(connPool[i].state == CONN_WRITE) {
			write++;
		}
		else if(connPool[i].state == CONN_READ) {
			read++;
		}
	}

	printf("connpool total: init = %d, use = %d, build = %d, write = %d, read = %d\n", init, use, build, write, read);
}
