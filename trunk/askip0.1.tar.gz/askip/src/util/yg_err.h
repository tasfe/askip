/*
 * yg_err.h
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 错误管理
 */

#ifndef YG_ERR_H_
#define YG_ERR_H_

#include "syshead.h"


#ifdef Debug
#define YG_ASSERT_EXIT  exit(-1)
#else
#define YG_ASSERT_EXIT  exit(-1)
#endif

#define YG_ASSERT(flag)      						\
do {												\
	if((flag) == 0) {  								\
		fprintf(stdout, "Error: %s::%s(%d) exit!", 	\
			__FILE__, __FUNCTION__, __LINE__);		\
		fflush(stdout);								\
		YG_ASSERT_EXIT;								\
	}  												\
}while(0)

#define YG_ASSERT_GOTO(flag, label)					\
do {												\
	if((flag) == 0) {  								\
		fprintf(stderr, "Error: %s::%s(%d) exit!", 	\
			__FILE__, __FUNCTION__, __LINE__);		\
		goto label;									\
	}  												\
}while(0)

#define YG_ASSERT_RET(flag, ret) 					\
do {												\
	if((flag) == 0) {  								\
		fprintf(stderr, "Error: %s::%s(%d) exit!", 	\
			__FILE__, __FUNCTION__, __LINE__);		\
		return ret;									\
	}  												\
}while(0)


#define YG_RET(flag, val) 							\
    if((flag) == 1)  return val						\



#endif /* YG_ERR_H_ */
