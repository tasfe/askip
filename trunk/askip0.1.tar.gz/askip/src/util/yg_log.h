/*
 * yg_log.h
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef YG_LOG_H_
#define YG_LOG_H_

#include "syshead.h"

typedef enum {
	YG_LOG_LEVEL_DEBUG = 200,
	YG_LOG_LEVEL_INFO,
	YG_LOG_LEVEL_WARN,
	YG_LOG_LEVEL_ERR,
	YG_LOG_CLOSE
}YG_LOG_LEVEL;


#define 	YG_LOG_CUR_LEVEL 		YG_LOG_LEVEL_WARN


void yg_printlog(int logType, char *fpath, char *fname, int line, char *fmt, ...);

#define YG_LOG_LOG(logType, fmt, ...)	\
do {	\
	if(logType >= YG_LOG_CUR_LEVEL) 	\
		yg_printlog(logType, (char *)__FILE__, (char *)__FUNCTION__, __LINE__, fmt, ## __VA_ARGS__);	\
} while(0)



#define YG_DEBUG(fmt, ...) 		YG_LOG_LOG(YG_LOG_LEVEL_DEBUG, 	fmt, ## __VA_ARGS__)
#define YG_INFO(fmt, ...) 		YG_LOG_LOG(YG_LOG_LEVEL_INFO, 	fmt, ## __VA_ARGS__)
#define YG_WARN(fmt, ...) 		YG_LOG_LOG(YG_LOG_LEVEL_WARN, 	fmt, ## __VA_ARGS__)
#define YG_ERR(fmt, ...) 		YG_LOG_LOG(YG_LOG_LEVEL_ERR, 	fmt, ## __VA_ARGS__)




#endif /* YG_LOG_H_ */
