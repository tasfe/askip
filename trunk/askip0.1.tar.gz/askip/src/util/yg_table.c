/*
 * wf_ltable.c
 *
 *   Created on: 2011-11-27
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "yg_table.h"


YgNode* yg_node_init(char *key, char *val)
{
	YG_ASSERT(key != NULL);

	YgNode *node = NULL;
	YG_MALLOC(node, sizeof(YgNode), YgNode *);
	YG_STRDUP(node->key, key);
	if(val != NULL) YG_STRDUP(node->val, val);

	return node;
}

void yg_node_free(YgNode *node)
{
	if(node != NULL) {
		YG_FREE(node->key);
		YG_FREE(node->val);
		YG_FREE(node);
	}
}

YgTable* yg_talbe_init(int size)
{
	YG_ASSERT(size > 0);

	YgTable *table;

	YG_MALLOC(table, sizeof(YgTable), YgTable *);
	YG_MALLOC(table->data, sizeof(YgNode *) * size, YgNode **);
	table->size = size;

	return table;
}

int yg_table_put(YgTable *table, char *key, char *val)
{
	YG_ASSERT(table != NULL);
	YG_ASSERT(key != NULL);

	int hash = yg_gethash(key, table->size);
	if(hash < 0) return -1;

	YgNode *newNode = yg_node_init(key, val);
	newNode->next = table->data[hash];
	table->data[hash] = newNode;

	return 0;
}

char* yg_table_get(YgTable *table, char *key)
{
	YG_ASSERT(table != NULL);
	YG_ASSERT(key != NULL);

	int hash = yg_gethash(key, table->size);
	if(hash < 0) return NULL;

	YgNode *p = table->data[hash];
	while(p != NULL) {
		if(strcmp(p->key, key) == 0) {
			return p->val;
		}

		p = p->next;
	}

	return NULL;
}

void yg_table_free(YgTable *table)
{
	if(table == NULL) return;

	if(table->data != NULL) {
		int i;
		for(i = 0; i < table->size; i++) {
			YgNode *p = table->data[i];
			while(p != NULL) {
				YgNode *tmp = p->next;
				yg_node_free(p);
				p = tmp;
			}
		}

		YG_FREE(table->data);
	}

	YG_FREE(table);
}






