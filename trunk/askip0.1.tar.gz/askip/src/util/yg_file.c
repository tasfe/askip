/*
 * yg_file.c
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */


#include "yg_file.h"

int yg_del_dir(char *dname)
{
	YG_ASSERT(dname != NULL);

    DIR *dir = opendir(dname);
    YG_ASSERT(dir != NULL);

    char fname[256];
    struct dirent *name = readdir(dir);
    while(1) {
    	if(name == NULL) return -1;
    	if(strncmp(name->d_name, ".", 1) != 0 && strncmp(name->d_name, "..", 2) != 0) {
    		snprintf(fname, "%s/%s", dname, name->d_name);
    		unlink(fname);
    	}
    	name = readdir(dir);
    }
    closedir(dir);

    return 0;
}
