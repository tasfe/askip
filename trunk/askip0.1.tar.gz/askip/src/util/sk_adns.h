/*
 * sk_adns.h
 *
 *  Created on: 2012-2-15
 *      Author: test
 */

#ifndef SK_ADNS_H_
#define SK_ADNS_H_

#include "adns.h"
#include "yg_mem.h"
#include "yg_err.h"

#define MAX_DNS_COUNT 10

typedef struct SkAdns
{
	adns_state ads;
	char ans_cname;
	unsigned int tryCount;
}SkAdns;

int 	sk_adns_init(SkAdns *skAdns);
int 	sk_adns_commit(SkAdns *skAdns, char *host);
char* 	sk_adns_query(SkAdns *skAdns);
void 	sk_adns_destory(SkAdns *skAdns);

#endif /* SK_ADNS_H_ */
