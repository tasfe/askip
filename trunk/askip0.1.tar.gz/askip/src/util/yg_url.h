/*
 * yg_util.h
 *
 *   Created on: 2011-11-23
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef YG_UTIL_H_
#define YG_UTIL_H_

#include "syshead.h"

char* yg_unescape_url(char *url);



#endif /* YG_UTIL_H_ */
