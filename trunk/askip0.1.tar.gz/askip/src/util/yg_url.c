/*
 * yg_util.c
 *
 *   Created on: 2011-11-23
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */


#include "yg_url.h"

char xc(char c)
{
	if(c <= '9') c -= '0';
	else if(c <= 'Z') c -= 'A' - 10;
	else c -= 'a' - 10;

	return c;
}

char x2c(char *xval)
{
	char c1 = xc(xval[0]);
	char c2 = xc(xval[1]);

	return (c1 << 4) + c2;
}

int wf_isdigit(char c)
{
	if(c >= '0' && c <= '9') return 1;
	if(c >= 'A' && c <= 'Z') return 1;
	if(c >= 'a' && c <= 'z') return 1;

	return 0;
}

char* yg_unescape_url(char *url)
{
	if(url == NULL) return NULL;

    int x = 0, y = 0;
    int urlLen = strlen(url);

    while(y < urlLen) {
    	if(url[y] != '%') url[x++] = url[y];
    	else {
    		if(y + 2 <= urlLen && wf_isdigit(url[y + 1]) && wf_isdigit(url[y + 2])) {
    			url[x++] = x2c(&url[y + 1]);
    			y += 2;
    		} else {
    			url[x++] = url[y];
    		}
    	}

    	y += 1;
    }
    url[x] = '\0';
    return url;
}
