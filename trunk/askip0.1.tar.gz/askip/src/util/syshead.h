/*
 * syshead.h
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 系统头文件
 */

#ifndef SYSHEAD_H_
#define SYSHEAD_H_


//  basic head
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <stdarg.h>

#include <errno.h>
#include <assert.h>

#include <signal.h>

// time head
#include <time.h>
#include <utime.h>

// file head
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>


//  net head
#include <sys/select.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>


//  sem  head
#include <semaphore.h>

// pthread
#include <pthread.h>

// process conn
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>

// regex
#include <regex.h>

#define bool int
#define false 0
#define true  1

#endif /* SYSHEAD_H_ */
