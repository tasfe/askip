#ifndef YG_DAEMON_H
#define YG_DAEMON_H

#include "syshead.h"

int  yg_daemon();
void yg_daemon_exit();

#endif
