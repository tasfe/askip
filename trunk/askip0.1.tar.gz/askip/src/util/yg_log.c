/*
 * yg_log.c
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "yg_log.h"

#define BUF_LEN 8192

char* yg_get_logtype(int logType)
{
	if(logType == YG_LOG_LEVEL_DEBUG) return "DEBUG";
	else if(logType == YG_LOG_LEVEL_ERR) return "ERR";
	return "LOG";
}

void yg_printlog(int logType, char *fpath, char *fname, int line, char *fmt, ...)
{
	char buf[BUF_LEN];
	char msg[BUF_LEN];

	memset(buf, 0, sizeof(buf));
	memset(msg, 0, sizeof(msg));

	va_list ap;
	va_start(ap, fmt);
	vsnprintf(buf, sizeof(buf) - 1, fmt, ap);
	va_end(ap);

	snprintf(msg, sizeof(msg) - 1, "[%s] %s::%s(%d) %s", \
			yg_get_logtype(logType), fpath, fname, line,	buf);
	fprintf(stdout, "%s\n", msg);
	fflush(stdout);
}

