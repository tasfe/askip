/*
 * yg_table.h
 *
 *   Created on: 2011-11-27
 *       Author: yegui@alibaba-inc.com
 *  Description:
 */

#ifndef YG_TABLE_H_
#define YG_TABLE_H_

#include "syshead.h"
#include "yg_mem.h"

typedef int (*yg_cmp)(void *pa, void *pb);

typedef struct YgNode
{
	char *key;
	char *val;
	struct YgNode *next;
}YgNode;

typedef struct YgTable
{
	int size;
	YgNode **data;
}YgTable;

YgNode*  yg_node_init(char *key, char *val);
void     yg_node_free(YgNode *node);

YgTable* yg_talbe_init(int size);
int      yg_table_put(YgTable *table, char *key, char *val);
char*    yg_table_get(YgTable *table, char *key);
void     yg_table_free(YgTable *table);



#endif
