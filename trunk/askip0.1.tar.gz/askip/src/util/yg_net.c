/*
 * yg_net.c
 *
 *   Created on: 2011-11-28
 *       Author:
 *  Description: 
 */

#include "yg_net.h"

char* yg_get_domain(const char *url)
{
	YG_ASSERT(url != NULL);

    int len;
    char *p, *domain;

    len = strlen(url);
    if(len < 8) return NULL;
    if(strncasecmp(url, "http://", strlen("http://")) != 0) return NULL;

    p = index(url + 7, '/');
    if(p != NULL) len = p - url;
    len -= 7;

    YG_MALLOC(domain, len + 1, char *);
    strncpy(domain, url + 7, len);

    return domain;
}

char* yg_get_file(char *url)
{
    char *file, *p;
    int len;

    YG_ASSERT(url != NULL);

    len = strlen(url);
    if(len < 9) return NULL;
    if(strncasecmp(url, "http://", strlen("http://")) != 0) return NULL;

    p = index(url + 7, '/');
    if(p == NULL){
        YG_STRDUP(file, "/");
        return file;
    }

    len = len - (p - url);
    YG_MALLOC(file, len + 1, char *);
    strncpy(file, p, len);

    return file;
}

char* yg_get_file1(char *url)
{
    char *file;

    YG_ASSERT(url != NULL);

    int len = strlen(url);
    YG_MALLOC(file, len + 1, char *);
    strncpy(file, url, len);

    return file;
}

int yg_get_rlen(char *p)
{
    if(p == NULL) return 0;

    int len = strlen(p) - 1;
    int rlen = len;
    while(len >=0 && p[len] != '/') len--;
    return rlen - len;
}

char* yg_get_file2(char *url, char *oldFile)
{
    char *file;

    YG_ASSERT(url != NULL);;
    YG_ASSERT(oldFile != NULL);;

    int len = strlen(url), len1 = strlen(oldFile) - yg_get_rlen(oldFile);

    YG_MALLOC(file, len + len1 + 1, char *);
    strncpy(file, oldFile, len1);
    strncpy(file + len1, url, len);

    return file;
}
