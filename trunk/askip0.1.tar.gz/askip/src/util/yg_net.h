/*
 * yg_net.h
 *
 *   Created on: 2011-11-28
 *       Author:
 *  Description: 
 */

#ifndef YG_NET_H_
#define YG_NET_H_

#include "syshead.h"
#include "yg_err.h"
#include "yg_mem.h"

char* yg_get_domain(const char *url);
char* yg_get_file(char *url);
char* yg_get_file1(char *url);
char* yg_get_file2(char *url, char *oldFile);



#endif /* YG_NET_H_ */
