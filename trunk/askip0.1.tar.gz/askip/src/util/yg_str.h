/*
 * yg_str.h
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef YG_STR_H_
#define YG_STR_H_


#include "syshead.h"

int yg_ltrim(char *buf);
int yg_rtrim(char *buf);
int yg_trim(char *buf);
char* yg_skip(char *p, char c);
int yg_str_cmp(char *stra, char *strb);
int yg_str_swith(char *str, char *pstr);
int yg_str_ewith(char *str, char *pstr);

int yg_gethash(char *str, unsigned int size);
int yg_hs2i(char *str);
int yg_str_move(char *str, int idx, int len);




#endif /* YG_STR_H_ */
