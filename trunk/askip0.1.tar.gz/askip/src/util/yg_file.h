/*
 * yg_file.h
 *
 *   Created on: 2011-12-2
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#ifndef YG_FILE_H_
#define YG_FILE_H_

#include "syshead.h"
#include "yg_err.h"



#endif /* YG_FILE_H_ */
