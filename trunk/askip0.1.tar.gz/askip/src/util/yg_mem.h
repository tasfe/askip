/*
 * yg_mem.h
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 内存管理的常见宏
 */

#ifndef YG_MEM_H_
#define YG_MEM_H_

#include "yg_err.h"

#define YG_MALLOC(p, size, type) 				\
do {											\
	p = (type)malloc(size);						\
	YG_ASSERT((p != NULL));						\
	if(p != NULL) memset(p, 0, size);			\
} while(0)

#define YG_REALLOC(p, size, type)		\
do {									\
	p = (type)realloc(p, size, type);	\
	YG_ASSERT((p != NULL));				\
}while(0)

#define YG_STRDUP(dstr, str) 			\
do {									\
	if(str != NULL) {					\
		dstr = strdup(str);				\
		YG_ASSERT((dstr != NULL));		\
	}									\
}while(0)

#define YG_FREE(str)					\
do {									\
	if(str != NULL) {					\
		free(str);						\
		str = NULL;						\
	}									\
}while(0)



#endif /* YG_MEM_H_ */
