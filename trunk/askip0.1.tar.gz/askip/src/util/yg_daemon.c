#include "yg_daemon.h"

#define DAEMON_FNAME 		"/dev/null"
#define PID_FNAME				"./pid.log"

int writeToFile(int pid)
{
	FILE *fp = fopen(PID_FNAME, "w");
	if(fp == NULL) return -1;
	
	fprintf(fp, "%d\n", pid);
	
	fclose(fp);
	
	return 0;
}

int yg_daemon()
{
	int pid = fork();
	if(pid == -1) return -1;
	if(pid > 0) _exit(0);
	
	if(setsid() == -1) return -1;
	
	int fd = open(DAEMON_FNAME, O_RDWR | O_CREAT | O_TRUNC, 006400);
	if(fd != -1) {
		if(fd != STDIN_FILENO) 		dup2(fd, STDIN_FILENO);
		if(fd != STDOUT_FILENO) 	dup2(fd, STDOUT_FILENO);
		if(fd != STDERR_FILENO)		dup2(fd, STDERR_FILENO);
		if(fd > STDERR_FILENO) 		close(fd);
	} 
	else 
		return -1;
	
	int iRet = writeToFile(getpid());
	
	return iRet;
}

void yg_daemon_exit()
{
	unlink(PID_FNAME);	
}
