/*
 * sk_adns.c
 *
 *  Created on: 2012-2-15
 *      Author: test
 */

#include "sk_adns.h"

int sk_adns_init(SkAdns *skAdns)
{
	YG_ASSERT(skAdns != NULL);

	memset(skAdns, 0, sizeof(SkAdns));

    adns_initflags flags;
    flags = adns_if_nosigpipe | adns_if_noerrprint;
    adns_init(&(skAdns->ads), flags, NULL);

    return 0;
}

int sk_adns_commit(SkAdns *skAdns, char *host)
{
	YG_ASSERT(skAdns != NULL);
	if(host == NULL || host[0] == '\0') return -1;

	adns_query quer = NULL;
	adns_submit(skAdns->ads, host, (adns_rrtype) adns_r_a, (adns_queryflags) 0, NULL, &quer);

	return 0;
}

char* sk_adns_query(SkAdns *skAdns)
{
	char cname[256];
    adns_answer *ans;
    adns_query quer = NULL;
    char *ip = NULL;
    char *tmpip = NULL;

    YG_ASSERT(skAdns != NULL);

	int res = adns_check(skAdns->ads, &quer, &ans, NULL);
	if(res == 0) {
		if (ans->status == adns_s_prohibitedcname) {
			memset(cname, 0, sizeof(cname));
			strncpy(cname, ans->cname, sizeof(cname) - 1);
			adns_submit(skAdns->ads, cname, (adns_rrtype) adns_r_addr, (adns_queryflags) 0, NULL, &quer);
			skAdns->ans_cname = 1;
		} else {
			if(ans->status == adns_s_ok) {
				if(skAdns->ans_cname)
					tmpip = inet_ntoa(ans->rrs.addr->addr.inet.sin_addr);
				else
					tmpip = inet_ntoa(*(ans->rrs.inaddr));

				YG_STRDUP(ip, tmpip);
			} else {
				skAdns->tryCount = MAX_DNS_COUNT;
			}

			adns_finish(skAdns->ads);
			skAdns->ads = NULL;
			return ip;
		}
	}
	else if (res == ESRCH || res == EAGAIN) {
		usleep(1000);
		skAdns->tryCount += 1;
	}

    return NULL;
}

void sk_adns_destory(SkAdns *skAdns)
{
	YG_ASSERT(skAdns != NULL);

	if(skAdns->ads)	{
		adns_finish(skAdns->ads);
		skAdns->ads = 0;
	}
}
