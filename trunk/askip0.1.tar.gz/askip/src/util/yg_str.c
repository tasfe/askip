/*
 * yg_str.c
 *
 *   Created on: 2011-10-28
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "yg_str.h"

int yg_ltrim(char *buf)
{
	if(buf == NULL) return -1;
	int len = strlen(buf);
	if(len == 0) return 0;

	int left = 0;
	while(left < len) {
		if(buf[left] != ' ') break;
		left++;
	}

	int i = left;
	while(i < len){
		buf[i - left] = buf[i];
		i++;
	}
	buf[len - left] = '\0';
	return 0;
}

int yg_rtrim(char *buf)
{
	if(buf == NULL) return -1;
	int len = strlen(buf);
	if(len == 0) return 0;

	int right = len - 1;
	while(right >= 0) {
		if(buf[right] != ' ') break;
		right -= 1;
	}
	buf[right + 1] = '\0';

	return 0;
}

int yg_trim(char *buf)
{
	if(yg_ltrim(buf) == -1) return -1;
	if(yg_rtrim(buf) == -1) return -1;

	return 0;
}

char* yg_skip(char *p, char c)
{
	if(p == NULL) return NULL;
	p = strchr(p, c);
	if(p == NULL) return NULL;
	p += 1;

	return p;
}

int yg_str_cmp(char *stra, char *strb)
{
	if(stra == NULL && strb == NULL)  return 0;
	if(stra == NULL)  return -1;
	if(strb == NULL)  return 1;

	return strcmp(stra, strb);
}

int yg_str_swith(char *str, char *pstr)
{
    if(str == NULL && pstr == NULL) return 0;
    if(str == NULL) return -1;
    if(pstr == NULL) return -1;

    size_t la = strlen(pstr);
    return !strncmp(pstr, str, la);
}

int yg_str_ewith(char *str, char *pstr)
{
    if(str == NULL && pstr == NULL) return 0;
    if(str == NULL) return -1;
    if(pstr == NULL) return -1;

    int lens = strlen(str) - 1;
    int lenps = strlen(pstr) - 1;
    if(lenps > lens) return -1;

    while(lenps >= 0) {
        if(str[lens] != pstr[lenps]) return -1;
        lenps -= 1; lens -= 1;
    }

    return 0;
}

int yg_gethash(char *str, unsigned int size)
{
	if(str == NULL || size <= 0) return -1;

	int hash = 0;
	while(*str) {
		hash = (hash << 7) + *str;
		str++;
	}

	if(hash < 0) hash = -hash;
	return hash % size;
}

int yg_h2i(char c)
{
	if(c >= '0' && c <= '9') return c - '0';
	if(c >= 'A' && c <= 'Z') return c - 'A' + 10;
	if(c >= 'a' && c <= 'z') return c - 'a' + 10;

	return -1;
}

int yg_hs2i(char *str)
{
	if(str == NULL) return 0;

	int ival = 0;
	while(*str) {
		int c = yg_h2i(*str);
		if(c == -1) return ival;
		ival = ival * 16 + c;

		str++;
	}
	return ival;
}

//  warning  checking?
int yg_str_move(char *str, int idx, int len)
{
	if(str == NULL) return -1;

	int i;
	for(i = 0; i < len; i++)
		str[i] = str[idx + i];
	str[idx + len] = '\0';

	return 0;
}
