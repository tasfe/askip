/*
 * askip.c
 *
 *  Created on: 2012-2-14
 *      Author: test
 */

#include "askip.h"
#include "dns_server.h"
#include "urlfile.h"
#include "urlpool.h"
#include "connpool.h"


Global global;


char* get_token(char **line)
{
	while(1) {
		if(**line == '\t' || **line == ' ') (*line)++;
		else if(**line == '#') return NULL;
		else break;
	}

	char *p = *line;
	while(**line != '\t' && **line != ' ' && **line != '\0') (*line)++;
	if(**line != '\0'){
		**line = '\0';
		(*line)++;
	}

	return p;
}

void parse_cfg(char *cfg)
{
	if(cfg == NULL) return;

	FILE *fp = fopen(cfg, "r");
	YG_ASSERT(fp != NULL);

	char line[4096];
	char *token;
	while(fgets(line, sizeof(line - 1), fp) != NULL) {
		token = get_token((char **)&line);
		while(token) {
			if(!strcmp(token, "daemon")) {
				yg_daemon();
			} else if(!strcmp(token, "startUrl")) {
				token = get_token((char **)&line);
				YG_ASSERT(token != NULL);
				YG_STRDUP(global.startUrl, token);
			} else if(!strcmp(token, "depth")) {
				token = get_token((char **)&line);
				YG_ASSERT(token != NULL);
				global.depth = atoi(token);
			} else if(!strcmp(token, "isDomain")) {
				global.inDomain = 1;
			}

			token = get_token((char **)&line);
		}
	}

	fclose(fp);
}

int sk_init(int argc, char **argv)
{
	//char *cfg = "askip.conf";
	char *cfg = NULL;

	int i = 1;
	while(i < argc) {
		if(!strcmp(cfg, "-c") && i + 1 < argc) {
			cfg = argv[i + 1];
			i += 1;
		}

		i += 1;
	}

	global.isRunning = 1;
	global.inDomain = 0;
	global.startUrl = "http://www.baidu.com/";
	global.depth 	= 5;
	global.urlCount = 0;
	global.connCount = 0;

	parse_cfg(cfg);

	YG_ASSERT(dns_server_init() == 0);
	YG_ASSERT(urlfile_init() == 0);
	YG_ASSERT(rgxhttp_init() == 0);
	YG_ASSERT(urlpool_init() == 0);
	YG_ASSERT(connpool_init() == 0);

	return 0;
}

void sk_destory()
{
	dns_server_destory();
	urlfile_destory();
	rgxhttp_free();
	urlpool_destory();
	connpool_destory();
}

int check_stop()
{
	if(!urlpool_isempty()) return 0;
	if(!connpool_isempty()) return 0;

	return 1;
}

int sk_skip()
{
	YG_ASSERT(url_parse(global.startUrl, NULL) == 0);
	while(global.isRunning)  {
		urlpool_full();
		if(check_stop()) break;
		urlpool_dns_full();
		connpool_full();
		do_fetch();

		urlpool_output();
		connpool_output();
	}

	return 0;

}

int main(int argc, char **argv)
{
	if(sk_init(argc, argv) == -1) {
		sk_destory();
		return -1;
	}

	sk_skip();

	sk_destory();
	return 0;
}
