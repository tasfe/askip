/*
 * htmlparse.c
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */

#include "htmlparse.h"

int rsp_init(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(rsp != NULL);

	memset(rsp, 0, sizeof(Rsp));
	rsp->resHead = yg_talbe_init(255);
	rsp->state = RES_ST_STATE;
	rsp->limit = RSP_BUF_SIZE;

	YG_ASSERT(rsp->resHead != NULL);

	return 0;
}

void rsp_free(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	if(rsp != NULL) {
		rsp->state = RES_ST_STATE;
		YG_FREE(rsp->proto);
		YG_FREE(rsp->reason);

		yg_table_free(rsp->resHead);
		rsp->resHead = NULL;

		rsp->isChunk = 0;
		rsp->r = rsp->w = 0;
	}
}

int parse_proto(Rsp *rsp, char *proto)
{
	YG_DEBUG("entry!\n");

	 YG_STRDUP(rsp->proto, proto);
	 return 0;
}

int parse_retstate(Rsp *rsp, char *retstate)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(retstate != NULL);
	rsp->stateCode = atoi(retstate);

	return 0;
}

int parse_reason(Rsp *rsp, char *reason)
{
	YG_DEBUG("entry!\n");

	YG_STRDUP(rsp->reason, reason);
	return 0;
}

int rsp_get_line(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	int lr = rsp->r;
	while(lr < rsp->w - 1) {
		if(rsp->buf[lr] == '\r' && rsp->buf[lr + 1] == '\n') {
			return lr;
		}
		lr += 1;
	}

	return -1;
}

int parse_stateline(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	int lr = rsp_get_line(rsp);
	if(lr == -1) return 0;
	rsp->buf[lr] = '\0';

	int iflag;
	char *ps, *pe;

	ps = rsp->buf + rsp->r;
	pe = strchr(ps, ' '); if(pe == NULL) return -1; *pe = '\0';
	iflag = parse_proto(rsp, ps);
	if(iflag == -1) return -1;

	ps = pe + 1;  if(ps == NULL) return -1;
	pe = strchr(ps, ' '); if(pe == NULL) return -1; *pe = '\0';
	iflag = parse_retstate(rsp, ps);
	if(iflag == -1) return -1;

	ps = pe + 1;  if(ps == NULL) return -1;
	iflag = parse_reason(rsp, ps);
	if(iflag == -1) return -1;

	rsp->state = RES_ST_HEAD;
	rsp->r = lr + 2;

	return 0;
}

int parse_body_pre(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	if(rsp->stateCode != 200) {
		rsp->state = RES_ST_END;
		return 0;
	}

	char *contLen = yg_table_get(rsp->resHead, "Content-Length");
	if(contLen != NULL) {
        rsp->contlen = atoi(contLen);
        if(rsp->contlen == 0) rsp->state = RES_ST_END;
        return 0;
	}

	char *chunk = yg_table_get(rsp->resHead, "Transfer-Encoding");
	if(chunk != NULL && strncmp(chunk, "chunked", strlen("chunked")) == 0) {
		rsp->isChunk = 1;
		return 0;
	}

	rsp->contlen = rsp->limit - 1;
	//YG_ASSERT(1 != 1);
	return 0;
}

int parse_head(Rsp *rsp)
{
	YG_DEBUG("entry!\n");

	while(1 == 1) {
		int lr = rsp_get_line(rsp);
		if(lr == -1) return 0;
		if(lr == rsp->r) {
			rsp->r += 2;
			rsp->state = RES_ST_BODY;
			parse_body_pre(rsp);
			return 0;
		}
		rsp->buf[lr] = '\0';

		char *ps = rsp->buf + rsp->r;
		char *pe = strchr(ps, ':');
		if(pe != NULL) {
			*pe = '\0';
			pe += 2;
			if(pe - rsp->buf < lr)
				yg_table_put(rsp->resHead, ps, pe);
		}

		rsp->r = lr + 2;
	}

	return 0;
}

int parse_body_cont(Rsp *rsp, Url *oldUrl)
{
	YG_DEBUG("entry!\n");

	if(rsp->contlen <= 0) {
		rsp->state = RES_ST_END;
		return 0;
	}

	int max = rsp->contlen;
	if(rsp->w - rsp->r < max) max = rsp->w - rsp->r;
	rsp->buf[rsp->r + max] = '\0';
	rgxhttp_match(rsp->buf + rsp->r, oldUrl);
	rsp->contlen -= max;
	rsp->r += max;

	return 0;
}

int parse_body(Rsp *rsp, Url *oldUrl)
{
	YG_DEBUG("entry!\n");

	if(rsp->isChunk == 1) {
		while(rsp->r < rsp->w) {
			if(rsp->contlen == 0) {
				int lr = rsp_get_line(rsp);
				if(lr == -1) return 0;
				rsp->buf[lr] = '\0';
				rsp->contlen = yg_hs2i(rsp->buf + rsp->r);
				rsp->r = lr + 2;
			}
			parse_body_cont(rsp, oldUrl);
			if(rsp->contlen == 0) {
				if(rsp->r + 2 > rsp->w) {
					// 可能有数据丢弃
					rsp->state == RES_ST_END;
					return 0;
				}
				rsp->r += 2;
			}
			// check....
			if(rsp->r < rsp->w && rsp->state == RES_ST_END) {
				YG_ASSERT(1 == 1);
			}
		}
	} else {
		parse_body_cont(rsp, oldUrl);
		if(rsp->contlen <= 0) {
			rsp->state = RES_ST_END;
			return 0;
		}
	}

	return 0;
}

int html_parse(Rsp *rsp, Url *oldUrl)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(rsp != NULL);
	//printf("html_parse: %s%s\n", oldUrl->host, oldUrl->file);

	if(rsp->state == RES_ST_STATE)
		if(parse_stateline(rsp) == -1){
			printf("%d %d\n", rsp->w, rsp->r);
			//YG_ASSERT(1 != 1);
			rsp->state = RES_ST_END;
			return -1;
		}
	if(rsp->state == RES_ST_HEAD)
		if(parse_head(rsp) == -1){
			//YG_ASSERT(1 != 1);
			rsp->state = RES_ST_END;
			return -1;
		}
	if(rsp->state == RES_ST_BODY)
		//writeToHtml(oldUrl->host, oldUrl->file, rsp->buf + rsp->r);

		if(parse_body(rsp, oldUrl) == -1){
			//YG_ASSERT(1 != 1);
			rsp->state = RES_ST_END;
			return -1;
		}

	return 0;
}
