/*
 * urlfile.c
 *
 *   Created on: 2011-12-3
 *       Author: yegui@alibaba-inc.com
 *  Description: 
 */


#include "urlpool.h"

#define URL_FILE_DIR  "./url/"
static int inUrlLine;  //  当前  in urlfile 拥有的行数
static int outUrlLine; //  当前  out urlfile 拥有的行数
static int inUrlName;
static int outUrlName;
static FILE *inUrlFp = NULL;
static FILE *outUrlFp = NULL;


int urlfile_in_open()
{
	YG_DEBUG("entry!\n");

	char fileName[256];

	if(inUrlFp != NULL) fclose(inUrlFp);

	snprintf(fileName, 255, "%s/%d", URL_FILE_DIR, inUrlName);
	inUrlFp = fopen(fileName, "r");
	YG_ASSERT(inUrlFp != NULL);

	inUrlName += 1;
	inUrlLine = 0;

	return 0;
}

int urlfile_out_open()
{
	YG_DEBUG("entry!\n");

	char fileName[256];

	if(outUrlFp != NULL) fclose(outUrlFp);

	snprintf(fileName, 255, "%s/%d", URL_FILE_DIR, outUrlName);
	outUrlFp = fopen(fileName, "a");
	YG_ASSERT(outUrlFp != NULL);

	outUrlName += 1;
	outUrlLine = 0;

	return 0;
}

int urlfile_write(Url *url)
{
	YG_DEBUG("entry!\n");

	YG_ASSERT(url != NULL);

	char line[16384];


	snprintf(line, sizeof(line) - 1, "%s %s %d", url->host, url->file, url->depth);
	int flag = fprintf(outUrlFp, "%s\n", line);
	fflush(outUrlFp);

	YG_ASSERT(flag != -1);

	if(++outUrlLine >= 1000) return urlfile_out_open();

	return 0;
}

int urlfile_read(Url *url)
{
	YG_DEBUG("entry!\n");
	YG_ASSERT(url != NULL);

	char line[16384];
	if(fgets(line, sizeof(line), inUrlFp) == NULL) return -2;
	if(++inUrlLine >= 1000) return urlfile_in_open();

	char *host = line;
	char *p = index(host, ' ');
	if(p == NULL)	return -1;   *p = '\0';
	strncpy(url->host, host, sizeof(url->host) - 1);

	char *file = p + 1;
	p = index(file, ' ');
	if(p == NULL) return -1; *p = '\0';
	strncpy(url->file, file, sizeof(url->file) - 1);

	char *depth = p + 1;
	p = index(depth, '\n');
	if(p == NULL) return -1; *p = '\0';
	url->depth = atoi(depth);
	if(url->depth <= 0) return -2;

    return 0;
}

void urlfile_delete()
{
	char fname[256];
    DIR *dir = opendir(URL_FILE_DIR);
    if(dir == NULL) return;

    struct dirent *name = readdir(dir);
    while(name != NULL) {
		sprintf(fname, "%s/%s",URL_FILE_DIR,  name->d_name);
		unlink(fname);

        name = readdir(dir);
    }
    closedir(dir);
}

int urlfile_init()
{
	urlfile_delete();
	urlfile_out_open();
	urlfile_in_open();

	return 0;
}

void urlfile_destory()
{
	if(outUrlFp != NULL) fclose(outUrlFp);
	if(inUrlFp != NULL) fclose(inUrlFp);
}
